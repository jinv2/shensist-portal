#!/bin/bash

# 获取当前脚本所在目录的绝对路径
BASE_DIR=$(cd "$(dirname "$0")"; pwd)
BIN_DIR="$BASE_DIR/bin"
ICON_PATH="$BIN_DIR/shensist_gui.py" # 暂时使用脚本作为路径参考
DESKTOP_FILE="$HOME/Desktop/ShensistCore.desktop"

echo "============================================"
echo "    SHENSIST CORE 桌面图标安装程序"
echo "============================================"

# 1. 创建桌面快捷方式文件
cat <<EOF > "$DESKTOP_FILE"
[Desktop Entry]
Version=1.0
Type=Application
Name=神思庭控制台
Comment=5.9TB 赛博资产创生系统
Exec=python3 $BIN_DIR/shensist_gui.py
Icon=utilities-terminal
Path=$BIN_DIR
Terminal=true
Categories=Development;
EOF

# 2. 赋予执行权限
chmod +x "$DESKTOP_FILE"
chmod +x "$BIN_DIR"/*.py

# 3. 处理 Ubuntu 桌面安全提示
# 在较新的 Ubuntu 上，图标需要手动“允许运行”
echo ">>> 桌面图标已生成在: $DESKTOP_FILE"
echo ">>> 请在桌面上右键点击图标，选择 'Allow Launching' (允许运行)。"
echo "============================================"
